import { motion } from "framer-motion";
import NavBar from "@/components/NavBar";
import Hero from "@/components/sections/Hero";
import Skills from "@/components/sections/Skills";
import Certificates from "@/components/sections/Certificates";
import Contact from "@/components/sections/Contact";
import ScrollToTop from "@/components/ScrollToTop";

export default function Home() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-background text-foreground overflow-hidden"
    >
      <NavBar />
      <main className="container mx-auto px-4 space-y-24 py-24">
        <Hero />
        <Skills />
        <Certificates />
        <Contact />
      </main>
      <ScrollToTop />
    </motion.div>
  );
}

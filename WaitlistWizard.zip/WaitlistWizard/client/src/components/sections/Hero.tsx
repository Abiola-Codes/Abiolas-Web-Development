import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  return (
    <section id="home" className="min-h-[calc(100vh-4rem)] flex items-center">
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Hi, I'm <span className="text-primary">Abiola Obafemi</span>
            <br />
            Young Programmer & Tech Enthusiast
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Passionate about coding, gaming, and building amazing things with technology.
          </p>
          <Button
            onClick={() => document.querySelector("#skills")?.scrollIntoView({ behavior: "smooth" })}
            className="group"
          >
            Explore My Skills
            <ArrowDown className="ml-2 h-4 w-4 group-hover:animate-bounce" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="relative aspect-square"
        >
          <img
            src="https://images.unsplash.com/photo-1599507593499-a3f7d7d97667"
            alt="Programming Setup"
            className="rounded-lg object-cover shadow-xl"
          />
          <div className="absolute inset-0 bg-primary/10 rounded-lg" />
        </motion.div>
      </div>
    </section>
  );
}